package com.minlink.minlink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinlinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinlinkApplication.class, args);
	}

}
